# Kids-Learning-Game
It is a learning game based on Python Gui. In this some images are shown on the screen and you have to choose the right answer according to the images.
